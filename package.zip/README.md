# Framer.com Replica

This is a pixel-perfect replica of Framer.com built with Next.js, React, TypeScript, and Tailwind CSS.

## Features

- **Home Page** - Hero section, features showcase, testimonials, experts, marketplace preview
- **Product Pages** - AI, Design, CMS, and other feature pages
- **Pricing Page** - Complete pricing table with toggle
- **Stories Page** - Customer stories and case studies
- **Marketplace Page** - Templates, components, and plugins
- **Blog Page** - Blog post listings
- **Experts Page** - Expert directory

## Tech Stack

- Next.js 14 (App Router)
- React 18
- TypeScript
- Tailwind CSS
- Framer Motion (animations)
- Lucide React (icons)

## Getting Started

### 1. Install Dependencies

```bash
npm install
```

### 2. Run Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### 3. Build for Production

```bash
npm run build
```

This creates a static export in the `dist` folder.

## Deployment

### Deploy to Vercel (Recommended)

1. Push this project to GitHub
2. Go to [Vercel](https://vercel.com) and sign up/login
3. Click "Add New Project"
4. Import your GitHub repository
5. Vercel will automatically detect Next.js and use the correct settings
6. Click "Deploy"

### Deploy to GitHub Pages

1. Create a GitHub repository
2. Push this code to the repository
3. Go to Settings → Pages
4. Select "GitHub Actions" as the source
5. Use the Next.js workflow
6. Your site will be available at `https://yourusername.github.io/repository-name`

## Project Structure

```
├── app/                    # Next.js app router pages
│   ├── page.tsx           # Home page
│   ├── layout.tsx         # Root layout
│   ├── globals.css        # Global styles
│   ├── ai/page.tsx        # AI feature page
│   ├── design/page.tsx    # Design feature page
│   ├── cms/page.tsx       # CMS feature page
│   ├── pricing/page.tsx   # Pricing page
│   ├── stories/page.tsx   # Customer stories
│   ├── marketplace/page.tsx # Marketplace
│   ├── blog/page.tsx      # Blog
│   └── experts/page.tsx   # Experts directory
├── components/            # React components
│   ├── Navbar.tsx         # Navigation bar
│   ├── Footer.tsx         # Footer
│   ├── Hero.tsx           # Hero section
│   ├── Features.tsx       # Features grid
│   ├── ScaleSection.tsx   # Scale features
│   ├── Testimonials.tsx   # Testimonials carousel
│   ├── Experts.tsx        # Experts section
│   ├── Marketplace.tsx    # Marketplace preview
│   └── CTA.tsx            # Call to action
├── public/                # Static assets
├── package.json           # Dependencies
├── next.config.js         # Next.js config
├── tailwind.config.ts     # Tailwind config
└── tsconfig.json          # TypeScript config
```

## Image Assets

All images are loaded directly from Framer's CDN. The images will continue to work as long as Framer's CDN serves them.

To download images locally:
1. Create a `public/images` folder
2. Download images from the CDN URLs used in the components
3. Update image paths in components to use local paths

## Customization

### Colors
Edit `tailwind.config.ts` to change the color scheme.

### Fonts
Edit `app/layout.tsx` to change the font. Currently using Inter from Google Fonts.

### Content
Update the content in each page component under the `app/` directory.

## License

This is a replica created for educational purposes. All trademarks and brand materials belong to Framer B.V.

## Credits

- Original design: [Framer](https://framer.com)
- Icons: [Lucide](https://lucide.dev)
- Animation: [Framer Motion](https://framer.com/motion)
