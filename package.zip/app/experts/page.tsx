"use client";

import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { motion } from "framer-motion";
import { Search, Star } from "lucide-react";

const experts = [
  {
    name: "Trueform",
    location: "Switzerland",
    specialty: "Web Design",
    rating: 5.0,
    projects: 50,
    image: "https://framerusercontent.com/images/ef3wgXef7UtZHsMSvRwgFetdc.jpeg",
  },
  {
    name: "Alex Aperios",
    location: "United Kingdom",
    specialty: "Development",
    rating: 4.9,
    projects: 35,
    image: "https://framerusercontent.com/images/LGLA6ocNPTiDQkXmTgCNzigXM.jpeg",
  },
  {
    name: "Analogue Agency",
    location: "Netherlands",
    specialty: "Branding",
    rating: 5.0,
    projects: 80,
    image: "https://framerusercontent.com/images/Juzj27np5nQ72k0J7YpYDkRadP8.jpeg",
  },
  {
    name: "Fabian Albert",
    location: "United States",
    specialty: "UI/UX Design",
    rating: 4.8,
    projects: 25,
    image: "https://framerusercontent.com/images/lRJZqAacf8QpT647xsXwoU5Kn4.jpeg",
  },
  {
    name: "Aerolab",
    location: "United States",
    specialty: "Web Design",
    rating: 5.0,
    projects: 100,
    image: "https://framerusercontent.com/images/sK7rKqHZBkgF2OJLJvHsHQSE1U.jpeg",
  },
  {
    name: "Deserve Studio",
    location: "United States",
    specialty: "Development",
    rating: 4.9,
    projects: 45,
    image: "https://framerusercontent.com/images/Juzj27np5nQ72k0J7YpYDkRadP8.jpeg",
  },
];

export default function Experts() {
  return (
    <main className="min-h-screen bg-neutral-50">
      <Navbar />
      <div className="pt-32 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-neutral-900 mb-6">
              Framer Experts
            </h1>
            <p className="text-lg text-neutral-600 max-w-2xl mx-auto">
              Hire the best Framer experts to help you build, launch, and scale
              your website.
            </p>
          </div>

          {/* Search */}
          <div className="max-w-xl mx-auto mb-12">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-neutral-400" />
              <input
                type="text"
                placeholder="Search experts by name or specialty..."
                className="w-full pl-12 pr-4 py-4 rounded-xl border border-neutral-200 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
              />
            </div>
          </div>

          {/* Experts Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {experts.map((expert, index) => (
              <motion.div
                key={expert.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white rounded-2xl p-6 border border-neutral-200 hover:border-neutral-300 hover:shadow-lg transition-all"
              >
                <div className="flex items-center gap-4 mb-4">
                  <img
                    src={expert.image}
                    alt={expert.name}
                    className="h-16 w-16 rounded-full object-cover"
                  />
                  <div>
                    <h3 className="font-semibold text-neutral-900">
                      {expert.name}
                    </h3>
                    <p className="text-sm text-neutral-500">
                      {expert.location}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 mb-4">
                  <span className="px-3 py-1 bg-neutral-100 text-neutral-700 text-xs font-medium rounded-full">
                    {expert.specialty}
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                    <span className="font-medium text-neutral-900">
                      {expert.rating}
                    </span>
                    <span className="text-sm text-neutral-500">
                      ({expert.projects} projects)
                    </span>
                  </div>
                  <button className="px-4 py-2 bg-black text-white text-sm font-medium rounded-lg hover:bg-neutral-800 transition-colors">
                    View Profile
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
      <Footer />
    </main>
  );
}
