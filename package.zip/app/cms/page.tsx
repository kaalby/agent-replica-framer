"use client";

import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { motion } from "framer-motion";
import { Database, FileText, List, Grid3X3 } from "lucide-react";

const features = [
  {
    icon: FileText,
    title: "Content Collections",
    description:
      "Organize your content into collections. Blog posts, products, team members—whatever you need to manage.",
  },
  {
    icon: List,
    title: "Rich Text Editor",
    description:
      "A powerful rich text editor that makes content creation a breeze. Add images, embeds, and format with ease.",
  },
  {
    icon: Grid3X3,
    title: "Dynamic Content",
    description:
      "Connect your content to your designs. Create dynamic pages that automatically update when your content changes.",
  },
  {
    icon: Database,
    title: "API Access",
    description:
      "Access your CMS content via API. Build custom integrations and sync with other tools in your workflow.",
  },
];

export default function CMS() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <div className="pt-32 pb-20">
        {/* Hero */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 px-4 py-2 bg-green-100 text-green-800 rounded-full text-sm font-medium mb-6"
            >
              <Database className="h-4 w-4" />
              CMS
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="text-4xl md:text-5xl lg:text-6xl font-bold text-neutral-900 mb-6"
            >
              Manage content
              <br />
              effortlessly
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-lg text-neutral-600 max-w-2xl mx-auto"
            >
              Manage and update your content effortlessly with a built-in CMS.
              Keep your site fresh without touching code.
            </motion.p>
          </div>

          {/* Feature Image */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="relative rounded-2xl overflow-hidden mb-20"
          >
            <img
              src="https://framerusercontent.com/images/w6D0Go6oSPqwIy3aBNxBEnvA8.png"
              alt="Framer CMS interface"
              className="w-full h-auto"
            />
          </motion.div>

          {/* Features Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="p-8 bg-neutral-50 rounded-2xl"
              >
                <div className="p-3 bg-white rounded-xl w-fit mb-6">
                  <feature.icon className="h-6 w-6 text-green-600" />
                </div>
                <h3 className="text-xl font-semibold text-neutral-900 mb-3">
                  {feature.title}
                </h3>
                <p className="text-neutral-600">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
      <Footer />
    </main>
  );
}
