"use client";

import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { motion } from "framer-motion";
import Link from "next/link";
import { ArrowRight, Clock } from "lucide-react";

const posts = [
  {
    title: "The State of Sites 2026: Key Trends and Insights",
    excerpt:
      "Discover the latest trends shaping the future of web design and development.",
    image: "https://framerusercontent.com/images/ZilMOyVNFhcvNyS9pG0hfM0Dv0.jpg",
    date: "Jan 15, 2026",
    readTime: "8 min read",
    category: "Trends",
  },
  {
    title: "How to Build a High-Converting Landing Page",
    excerpt:
      "Learn the principles of effective landing page design that drives conversions.",
    image: "https://framerusercontent.com/images/AyPzyMylJEo92lHDAr0UVgNN0.jpg",
    date: "Jan 10, 2026",
    readTime: "5 min read",
    category: "Tutorial",
  },
  {
    title: "Introducing AI-Powered Layout Generation",
    excerpt:
      "Experience the future of web design with our new AI features.",
    image: "https://framerusercontent.com/images/w6D0Go6oSPqwIy3aBNxBEnvA8.png",
    date: "Jan 5, 2026",
    readTime: "4 min read",
    category: "Announcement",
  },
  {
    title: "The Ultimate Guide to Framer CMS",
    excerpt:
      "Everything you need to know about managing content in Framer.",
    image: "https://framerusercontent.com/images/WB79UA8D6HufwUmuGE9WE1kIvD0.jpg",
    date: "Dec 28, 2025",
    readTime: "10 min read",
    category: "Guide",
  },
  {
    title: "SEO Best Practices for Framer Sites",
    excerpt:
      "Optimize your Framer site for search engines with these proven strategies.",
    image: "https://framerusercontent.com/images/Vop2a6Qgb62EAIB7lEzyqGTu2h0.png",
    date: "Dec 20, 2025",
    readTime: "6 min read",
    category: "SEO",
  },
  {
    title: "Building Accessible Websites with Framer",
    excerpt:
      "Create inclusive web experiences that work for everyone.",
    image: "https://framerusercontent.com/images/FAI4P9UsKm9pcZ4Y24wWOedWPw.png",
    date: "Dec 15, 2025",
    readTime: "7 min read",
    category: "Accessibility",
  },
];

export default function Blog() {
  return (
    <main className="min-h-screen bg-neutral-50">
      <Navbar />
      <div className="pt-32 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-neutral-900 mb-6">
              Blog
            </h1>
            <p className="text-lg text-neutral-600 max-w-2xl mx-auto">
              Insights, tutorials, and updates from the Framer team.
            </p>
          </div>

          {/* Posts Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {posts.map((post, index) => (
              <motion.article
                key={post.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Link href={`/blog/${post.title.toLowerCase().replace(/\s+/g, "-")}/`} className="group block">
                  <div className="relative aspect-[16/10] rounded-2xl overflow-hidden mb-4">
                    <img
                      src={post.image}
                      alt={post.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    <div className="absolute top-4 left-4">
                      <span className="px-3 py-1 bg-white/90 backdrop-blur-sm text-xs font-medium rounded-full">
                        {post.category}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-neutral-500 mb-3">
                    <span>{post.date}</span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {post.readTime}
                    </span>
                  </div>
                  <h2 className="text-xl font-semibold text-neutral-900 mb-2 group-hover:text-primary transition-colors">
                    {post.title}
                  </h2>
                  <p className="text-neutral-600 text-sm mb-4">{post.excerpt}</p>
                  <span className="inline-flex items-center text-sm font-medium text-neutral-900 group-hover:text-primary transition-colors">
                    Read more
                    <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </span>
                </Link>
              </motion.article>
            ))}
          </div>
        </div>
      </div>
      <Footer />
    </main>
  );
}
