"use client";

import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { motion } from "framer-motion";
import { Server, Shield, Zap, Globe } from "lucide-react";

const features = [
  {
    icon: Server,
    title: "Global CDN",
    description:
      "Your site is served from 100+ locations worldwide for the fastest possible load times, no matter where your visitors are.",
  },
  {
    icon: Shield,
    title: "SSL Security",
    description:
      "Free SSL certificates for all custom domains. Your sites are automatically secured with HTTPS.",
  },
  {
    icon: Zap,
    title: "Edge Network",
    description:
      "Content is cached at the edge and served from locations closest to your visitors for minimal latency.",
  },
  {
    icon: Globe,
    title: "99.99% Uptime",
    description:
      "Enterprise-grade infrastructure ensures your site stays online. We handle the servers so you can focus on design.",
  },
];

export default function Hosting() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <div className="pt-32 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-100 text-indigo-800 rounded-full text-sm font-medium mb-6"
            >
              <Server className="h-4 w-4" />
              Hosting
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="text-4xl md:text-5xl lg:text-6xl font-bold text-neutral-900 mb-6"
            >
              Lightning-fast
              <br />
              global hosting
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-lg text-neutral-600 max-w-2xl mx-auto"
            >
              Enterprise-grade hosting built for speed and reliability. SSL,
              CDN, and edge caching included with every site.
            </motion.p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="p-8 bg-neutral-50 rounded-2xl"
              >
                <div className="p-3 bg-white rounded-xl w-fit mb-6">
                  <feature.icon className="h-6 w-6 text-indigo-600" />
                </div>
                <h3 className="text-xl font-semibold text-neutral-900 mb-3">
                  {feature.title}
                </h3>
                <p className="text-neutral-600">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
      <Footer />
    </main>
  );
}
