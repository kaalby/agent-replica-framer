"use client";

import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { motion } from "framer-motion";
import { Sparkles, Wand2, Layout, Code, ImageIcon } from "lucide-react";

const features = [
  {
    icon: Wand2,
    title: "AI Layout Generation",
    description:
      "Generate complete page layouts from simple text prompts. Describe what you want, and watch as AI creates professional designs instantly.",
  },
  {
    icon: Layout,
    title: "Smart Components",
    description:
      "AI understands design patterns and creates components that work seamlessly together, maintaining consistency across your entire site.",
  },
  {
    icon: Code,
    title: "Code Generation",
    description:
      "Need custom functionality? AI can generate code snippets and custom components to extend your site&apos;s capabilities.",
  },
  {
    icon: ImageIcon,
    title: "Image Generation",
    description:
      "Generate custom images directly in Framer. Create hero images, backgrounds, and illustrations that match your brand.",
  },
];

export default function AI() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <div className="pt-32 pb-20">
        {/* Hero */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 px-4 py-2 bg-purple-100 text-purple-800 rounded-full text-sm font-medium mb-6"
            >
              <Sparkles className="h-4 w-4" />
              Powered by AI
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="text-4xl md:text-5xl lg:text-6xl font-bold text-neutral-900 mb-6"
            >
              Design with the power
              <br />
              of AI
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-lg text-neutral-600 max-w-2xl mx-auto"
            >
              Generate page layouts and advanced components in seconds with AI,
              so you can skip the blank canvas and start designing with
              confidence.
            </motion.p>
          </div>

          {/* Feature Image */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="relative rounded-2xl overflow-hidden mb-20"
          >
            <img
              src="https://framerusercontent.com/images/ZilMOyVNFhcvNyS9pG0hfM0Dv0.jpg"
              alt="Framer AI interface"
              className="w-full h-auto"
            />
          </motion.div>

          {/* Features Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="p-8 bg-neutral-50 rounded-2xl"
              >
                <div className="p-3 bg-white rounded-xl w-fit mb-6">
                  <feature.icon className="h-6 w-6 text-purple-600" />
                </div>
                <h3 className="text-xl font-semibold text-neutral-900 mb-3">
                  {feature.title}
                </h3>
                <p className="text-neutral-600">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
      <Footer />
    </main>
  );
}
