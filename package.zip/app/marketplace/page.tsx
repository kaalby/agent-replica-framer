"use client";

import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { motion } from "framer-motion";
import Link from "next/link";
import { Search, Filter } from "lucide-react";

const categories = [
  { name: "All", count: 1200 },
  { name: "Templates", count: 450 },
  { name: "Components", count: 380 },
  { name: "Plugins", count: 270 },
  { name: "Vectors", count: 100 },
];

const items = [
  {
    title: "Milo",
    type: "Template",
    description: "Furniture shop website",
    image: "https://framerusercontent.com/images/d4YjsL7yalSYZREJ1IdNPmw.jpg",
    price: "$49",
    author: "Fouroom",
  },
  {
    title: "Archer",
    type: "Template",
    description: "Creative portfolio",
    image: "https://framerusercontent.com/images/W1Q88PlQfYXaGug9EBkmai9By4.jpg",
    price: "$39",
    author: "Minimal",
  },
  {
    title: "Image Slider",
    type: "Component",
    description: "Before and after comparison",
    image: "https://framerusercontent.com/images/8VfS5zuMmDchIpaCf767I8rX7Y.jpg",
    price: "Free",
    author: "Framer",
  },
  {
    title: "Notion Sync",
    type: "Plugin",
    description: "Sync your Notion content",
    image: "https://framerusercontent.com/images/c8yQcxKjBlCZWoqWoRoBRvjcKo.jpg",
    price: "$15/mo",
    author: "Notion",
  },
  {
    title: "Apex Films",
    type: "Template",
    description: "Multimedia portfolio",
    image: "https://framerusercontent.com/images/uS0nUv30GToaflDaraI9qVUIwU.png",
    price: "$59",
    author: "Studio",
  },
  {
    title: "Hover Zoom",
    type: "Component",
    description: "Zoom and pan on hover",
    image: "https://framerusercontent.com/images/KCk7nP2M4mP1QclNxHPIrT1FvcA.jpg",
    price: "Free",
    author: "Framer",
  },
];

export default function Marketplace() {
  return (
    <main className="min-h-screen bg-neutral-50">
      <Navbar />
      <div className="pt-32 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-neutral-900 mb-6">
              Marketplace
            </h1>
            <p className="text-lg text-neutral-600 max-w-2xl mx-auto">
              Discover templates, components, and plugins to supercharge your
              Framer projects.
            </p>
          </div>

          {/* Search and Filter */}
          <div className="flex flex-col sm:flex-row items-center gap-4 mb-12">
            <div className="relative flex-1 max-w-xl w-full">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-neutral-400" />
              <input
                type="text"
                placeholder="Search templates, components, plugins..."
                className="w-full pl-12 pr-4 py-3 rounded-xl border border-neutral-200 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
              />
            </div>
            <button className="flex items-center gap-2 px-4 py-3 bg-white border border-neutral-200 rounded-xl hover:bg-neutral-50 transition-colors">
              <Filter className="h-5 w-5" />
              Filters
            </button>
          </div>

          {/* Categories */}
          <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8">
            {categories.map((category) => (
              <button
                key={category.name}
                className={`flex items-center gap-2 px-4 py-2 rounded-full whitespace-nowrap transition-colors ${
                  category.name === "All"
                    ? "bg-black text-white"
                    : "bg-white text-neutral-600 hover:bg-neutral-100 border border-neutral-200"
                }`}
              >
                {category.name}
                <span
                  className={`text-xs px-2 py-0.5 rounded-full ${
                    category.name === "All"
                      ? "bg-white/20"
                      : "bg-neutral-100 text-neutral-500"
                  }`}
                >
                  {category.count}
                </span>
              </button>
            ))}
          </div>

          {/* Items Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {items.map((item, index) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Link
                  href={`/marketplace/${item.type.toLowerCase()}s/${item.title.toLowerCase().replace(/\s+/g, "-")}/`}
                  className="group block bg-white rounded-2xl overflow-hidden border border-neutral-200 hover:border-neutral-300 hover:shadow-lg transition-all"
                >
                  <div className="relative aspect-[4/3] overflow-hidden">
                    <img
                      src={item.image}
                      alt={item.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    <div className="absolute top-4 left-4">
                      <span className="px-3 py-1 bg-white/90 backdrop-blur-sm text-xs font-medium rounded-full">
                        {item.type}
                      </span>
                    </div>
                  </div>
                  <div className="p-5">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-semibold text-neutral-900">
                        {item.title}
                      </h3>
                      <span className="font-semibold text-neutral-900">
                        {item.price}
                      </span>
                    </div>
                    <p className="text-sm text-neutral-500 mb-4">
                      {item.description}
                    </p>
                    <p className="text-xs text-neutral-400">by {item.author}</p>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
      <Footer />
    </main>
  );
}
