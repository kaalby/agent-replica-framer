"use client";

import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { motion } from "framer-motion";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

const stories = [
  {
    company: "Cradle",
    quote:
      "With Framer, our designers can ship updates daily. No dev handoff. No staging hassle.",
    author: "Jelle Prins",
    role: "Co-Founder",
    image: "https://framerusercontent.com/images/du8RmYLySzMLh8EnmrV2AISXU.jpg",
  },
  {
    company: "Miro",
    quote:
      "Framer allowed us to ship high-performing, beautifully designed pages at record speed.",
    author: "Radoslav Bali",
    role: "Design Lead",
    image: "https://framerusercontent.com/images/9vl2Y5wtIRc5hdlxM0YygMMq4.jpg",
  },
  {
    company: "Perplexity",
    quote:
      "Framer has completely transformed how we approach web design and content management.",
    author: "Sarah Chen",
    role: "Head of Design",
    image: "https://framerusercontent.com/images/jahA3XCoyymepzfVgARpulpS088.jpg",
  },
];

export default function Stories() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <div className="pt-32 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-neutral-900 mb-6">
              Customer Stories
            </h1>
            <p className="text-lg text-neutral-600 max-w-2xl mx-auto">
              See how leading companies use Framer to build and ship stunning
              websites faster than ever before.
            </p>
          </div>

          {/* Stories Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {stories.map((story, index) => (
              <motion.div
                key={story.company}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="group"
              >
                <Link
                  href={`/stories/${story.company.toLowerCase()}/`}
                  className="block"
                >
                  <div className="relative aspect-[4/3] rounded-2xl overflow-hidden mb-6">
                    <img
                      src={story.image}
                      alt={story.company}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-2xl font-bold text-white">
                        {story.company}
                      </h3>
                    </div>
                  </div>
                  <blockquote className="text-lg text-neutral-700 mb-4">
                    &ldquo;{story.quote}&rdquo;
                  </blockquote>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-neutral-900">
                        {story.author}
                      </p>
                      <p className="text-sm text-neutral-500">{story.role}</p>
                    </div>
                    <ArrowRight className="h-5 w-5 text-neutral-400 group-hover:text-neutral-900 transition-colors" />
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
      <Footer />
    </main>
  );
}
