"use client";

import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { motion } from "framer-motion";
import { Palette, MousePointer, Layers, Move } from "lucide-react";

const features = [
  {
    icon: MousePointer,
    title: "Visual Design",
    description:
      "Design everything visually. From layout to typography to effects, all without writing a single line of code.",
  },
  {
    icon: Layers,
    title: "Responsive Layouts",
    description:
      "Create responsive designs that look great on every device. Framer automatically adapts your layouts for desktop, tablet, and mobile.",
  },
  {
    icon: Move,
    title: "Animations & Interactions",
    description:
      "Add stunning animations and interactions with a few clicks. From hover effects to scroll-triggered animations.",
  },
  {
    icon: Palette,
    title: "Design Systems",
    description:
      "Build and maintain design systems with shared colors, typography, and components that sync across your entire site.",
  },
];

export default function Design() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <div className="pt-32 pb-20">
        {/* Hero */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 px-4 py-2 bg-blue-100 text-blue-800 rounded-full text-sm font-medium mb-6"
            >
              <Palette className="h-4 w-4" />
              Design
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="text-4xl md:text-5xl lg:text-6xl font-bold text-neutral-900 mb-6"
            >
              Craft beautiful
              <br />
              designs visually
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-lg text-neutral-600 max-w-2xl mx-auto"
            >
              Craft responsive layouts and bring them to life with smooth effects,
              interactions, and animations. Build exactly what you imagine,
              visually.
            </motion.p>
          </div>

          {/* Feature Image */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="relative rounded-2xl overflow-hidden mb-20"
          >
            <img
              src="https://framerusercontent.com/images/AyPzyMylJEo92lHDAr0UVgNN0.jpg"
              alt="Framer Design interface"
              className="w-full h-auto"
            />
          </motion.div>

          {/* Features Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="p-8 bg-neutral-50 rounded-2xl"
              >
                <div className="p-3 bg-white rounded-xl w-fit mb-6">
                  <feature.icon className="h-6 w-6 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold text-neutral-900 mb-3">
                  {feature.title}
                </h3>
                <p className="text-neutral-600">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
      <Footer />
    </main>
  );
}
