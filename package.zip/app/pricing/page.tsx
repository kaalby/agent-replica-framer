"use client";

import { useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Check, Sparkles } from "lucide-react";
import Link from "next/link";

const plans = [
  {
    name: "Free",
    description: "For personal projects and learning",
    price: { monthly: 0, yearly: 0 },
    features: [
      "Unlimited projects",
      "Framer domain",
      "Framer branding",
      "Community support",
    ],
    cta: "Start for free",
    popular: false,
  },
  {
    name: "Mini",
    description: "For simple sites with up to 2 pages",
    price: { monthly: 10, yearly: 8 },
    features: [
      "Custom domain",
      "No Framer branding",
      "2 pages",
      "50 CMS items",
    ],
    cta: "Get started",
    popular: false,
  },
  {
    name: "Basic",
    description: "For personal sites and blogs",
    price: { monthly: 20, yearly: 16 },
    features: [
      "Custom domain",
      "No Framer branding",
      "150 pages",
      "1,000 CMS items",
      "Password protection",
    ],
    cta: "Get started",
    popular: true,
  },
  {
    name: "Pro",
    description: "For larger sites and businesses",
    price: { monthly: 40, yearly: 32 },
    features: [
      "Everything in Basic",
      "Unlimited pages",
      "10,000 CMS items",
      "Analytics",
      "Staged publishing",
      "Redirects",
    ],
    cta: "Get started",
    popular: false,
  },
  {
    name: "Enterprise",
    description: "For teams and large organizations",
    price: { monthly: "Custom", yearly: "Custom" },
    features: [
      "Everything in Pro",
      "Unlimited CMS items",
      "SSO & SAML",
      "Advanced security",
      "Dedicated support",
      "Custom contracts",
    ],
    cta: "Contact sales",
    popular: false,
  },
];

export default function Pricing() {
  const [billing, setBilling] = useState<"monthly" | "yearly">("yearly");

  return (
    <main className="min-h-screen">
      <Navbar />
      <div className="pt-32 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-neutral-900 mb-6">
              Simple, transparent pricing
            </h1>
            <p className="text-lg text-neutral-600 max-w-2xl mx-auto">
              Start for free, then upgrade when you&apos;re ready to launch. No
              hidden fees, cancel anytime.
            </p>

            {/* Billing Toggle */}
            <div className="flex items-center justify-center gap-4 mt-8">
              <button
                onClick={() => setBilling("monthly")}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  billing === "monthly"
                    ? "bg-black text-white"
                    : "text-neutral-600 hover:text-neutral-900"
                }`}
              >
                Monthly
              </button>
              <button
                onClick={() => setBilling("yearly")}
                className={`px-4 py-2 rounded-lg font-medium transition-colors flex items-center gap-2 ${
                  billing === "yearly"
                    ? "bg-black text-white"
                    : "text-neutral-600 hover:text-neutral-900"
                }`}
              >
                Yearly
                <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full">
                  Save 20%
                </span>
              </button>
            </div>
          </div>

          {/* Plans Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
            {plans.map((plan) => (
              <div
                key={plan.name}
                className={`relative rounded-2xl p-6 border ${
                  plan.popular
                    ? "border-primary bg-blue-50/50"
                    : "border-neutral-200 bg-white"
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <span className="inline-flex items-center gap-1 px-3 py-1 bg-primary text-white text-xs font-semibold rounded-full">
                      <Sparkles className="h-3 w-3" />
                      Popular
                    </span>
                  </div>
                )}

                <div className="mb-4">
                  <h3 className="text-lg font-semibold text-neutral-900">
                    {plan.name}
                  </h3>
                  <p className="text-sm text-neutral-500 mt-1">
                    {plan.description}
                  </p>
                </div>

                <div className="mb-6">
                  {typeof plan.price[billing] === "number" ? (
                    <div className="flex items-baseline">
                      <span className="text-3xl font-bold text-neutral-900">
                        ${plan.price[billing]}
                      </span>
                      <span className="text-neutral-500 ml-2">/month</span>
                    </div>
                  ) : (
                    <span className="text-2xl font-bold text-neutral-900">
                      {plan.price[billing]}
                    </span>
                  )}
                </div>

                <ul className="space-y-3 mb-6">
                  {plan.features.map((feature) => (
                    <li
                      key={feature}
                      className="flex items-start gap-2 text-sm text-neutral-600"
                    >
                      <Check className="h-4 w-4 text-green-600 mt-0.5 shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>

                <Link
                  href="/signup/"
                  className={`block w-full text-center py-2.5 rounded-lg font-medium transition-colors ${
                    plan.popular
                      ? "bg-primary text-white hover:bg-primary-dark"
                      : "bg-black text-white hover:bg-neutral-800"
                  }`}
                >
                  {plan.cta}
                </Link>
              </div>
            ))}
          </div>
        </div>
      </div>
      <Footer />
    </main>
  );
}
