"use client";

import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { motion } from "framer-motion";
import { Search, Globe, Zap, BarChart3 } from "lucide-react";

const features = [
  {
    icon: Search,
    title: "SEO Optimization",
    description:
      "Built-in SEO tools to help your site rank higher in search results. Edit meta titles, descriptions, and Open Graph tags.",
  },
  {
    icon: Globe,
    title: "Custom Domains",
    description:
      "Connect your own domain for a professional presence. Free SSL certificates included with every site.",
  },
  {
    icon: Zap,
    title:="Performance",
    description:
      "Lightning-fast load times with automatic optimization. Perfect Lighthouse scores out of the box.",
  },
  {
    icon: BarChart3,
    title:="Analytics",
    description:
      "Track your site's performance with built-in analytics. Understand your visitors and optimize for growth.",
  },
];

export default function SEO() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <div className="pt-32 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 px-4 py-2 bg-orange-100 text-orange-800 rounded-full text-sm font-medium mb-6"
            >
              <Search className="h-4 w-4" />
              SEO
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="text-4xl md:text-5xl lg:text-6xl font-bold text-neutral-900 mb-6"
            >
              Rank higher with
              <br />
              built-in SEO
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-lg text-neutral-600 max-w-2xl mx-auto"
            >
              Optimize every page with built-in SEO settings, metadata, and
              blazing-fast hosting.
            </motion.p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="p-8 bg-neutral-50 rounded-2xl"
              >
                <div className="p-3 bg-white rounded-xl w-fit mb-6">
                  <feature.icon className="h-6 w-6 text-orange-600" />
                </div>
                <h3 className="text-xl font-semibold text-neutral-900 mb-3">
                  {feature.title}
                </h3>
                <p className="text-neutral-600">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
      <Footer />
    </main>
  );
}
