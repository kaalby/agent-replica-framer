import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Hero from "@/components/Hero";
import Features from "@/components/Features";
import ScaleSection from "@/components/ScaleSection";
import Testimonials from "@/components/Testimonials";
import Experts from "@/components/Experts";
import Marketplace from "@/components/Marketplace";
import CTA from "@/components/CTA";

export default function Home() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <Hero />
      <Features />
      <ScaleSection />
      <Testimonials />
      <Experts />
      <Marketplace />
      <CTA />
      <Footer />
    </main>
  );
}
