# Framer.com Replica Project Structure

## Pages to Replicate:
1. Home (/) - Main landing page
2. AI (/ai/) - AI features
3. Design (/design/) - Design features
4. Publish (/publish/) - Publishing features
5. Collaborate (/collaborate/) - Collaboration features
6. Convert (/convert/) - Conversion features
7. CMS (/cms/) - Content management
8. SEO (/seo/) - SEO features
9. Hosting (/hosting/) - Hosting info
10. Performance (/performance/) - Performance features
11. Analytics (/analytics/) - Analytics features
12. Pricing (/pricing/) - Pricing page
13. Switch (/switch/) - Switch to Framer
14. Startups (/startups/) - Startup program
15. Agencies (/agencies/) - Agency program
16. Enterprise (/enterprise/) - Enterprise solutions
17. Stories (/stories/) - Customer stories
18. Marketplace (/marketplace/) - Templates, plugins, components
19. Experts (/experts/) - Expert directory
20. Blog (/blog/) - Blog
