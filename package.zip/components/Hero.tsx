"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { ArrowRight, Sparkles } from "lucide-react";

const websiteImages = [
  "https://framerusercontent.com/images/8VfS5zuMmDchIpaCf767I8rX7Y.jpg",
  "https://framerusercontent.com/images/KCk7nP2M4mP1QclNxHPIrT1FvcA.jpg",
  "https://framerusercontent.com/images/6SXUv7jMAEkw8PabtmC6TXNIiM.jpg",
  "https://framerusercontent.com/images/PruQlxKuftAZHgOh7hJT3jaUbs.jpg",
  "https://framerusercontent.com/images/d4YjsL7yalSYZREJ1IdNPmw.jpg",
  "https://framerusercontent.com/images/W1Q88PlQfYXaGug9EBkmai9By4.jpg",
  "https://framerusercontent.com/images/uS0nUv30GToaflDaraI9qVUIwU.png",
  "https://framerusercontent.com/images/gmhdX4XPuJvQqId9jDmFHb7cFE.jpg",
  "https://framerusercontent.com/images/4pTVxnxo0Bvii8xP7hCmmozqx7s.jpg",
  "https://framerusercontent.com/images/Hp4KG1pwKb6cl66bNB9b2pYWQ3Y.jpg",
  "https://framerusercontent.com/images/c8yQcxKjBlCZWoqWoRoBRvjcKo.jpg",
  "https://framerusercontent.com/images/cx71XZYYWfIozOc1rn55Bw.jpg",
  "https://framerusercontent.com/images/pzsEcmp12GBybVJMMHJIQiRfEAQ.jpg",
  "https://framerusercontent.com/images/HnQI4uTAjbgziEmMMInd3R6o9c.jpg",
  "https://framerusercontent.com/images/iR48olgey2UZQ9FFhsWFne27Ag.jpg",
  "https://framerusercontent.com/images/JUWRJbfPWXb05lTNw0q4p1jewc.jpg",
];

export default function Hero() {
  return (
    <section className="relative pt-32 pb-20 lg:pt-40 lg:pb-32 overflow-hidden">
      {/* Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-blue-50/50 to-white pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-4xl mx-auto">
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center px-4 py-2 bg-black text-white rounded-full text-sm font-medium mb-8"
          >
            <span className="mr-2">State of Sites &apos;26</span>
            <span className="text-neutral-400">Unlock the report now</span>
            <ArrowRight className="ml-2 h-4 w-4" />
          </motion.div>

          {/* Heading */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight text-neutral-900 mb-6"
          >
            Build better
            <br />
            sites, faster
          </motion.h1>

          {/* Description */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-lg md:text-xl text-neutral-600 max-w-2xl mx-auto mb-10"
          >
            Framer is the site builder trusted by leading startups and Fortune
            500 companies. Build fast and scale more easily with an integrated
            CMS, analytics, localization, and SEO.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-8"
          >
            <Link
              href="/signup/"
              className="inline-flex items-center px-6 py-3 bg-black text-white rounded-lg font-medium hover:bg-neutral-800 transition-colors"
            >
              Start for free
            </Link>
            <Link
              href="/ai/"
              className="inline-flex items-center px-6 py-3 bg-white border border-neutral-200 text-neutral-900 rounded-lg font-medium hover:bg-neutral-50 transition-colors"
            >
              <Sparkles className="mr-2 h-4 w-4" />
              Start with AI
            </Link>
          </motion.div>

          {/* Meet Customers Link */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <Link
              href="/stories/"
              className="text-sm text-neutral-600 hover:text-neutral-900 underline underline-offset-4"
            >
              Meet our customers
            </Link>
          </motion.div>
        </div>

        {/* Website Showcase Grid */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="mt-16 lg:mt-24"
        >
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3 md:gap-4">
            {websiteImages.map((src, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4, delay: 0.5 + index * 0.05 }}
                className="relative aspect-[9/16] rounded-xl overflow-hidden bg-neutral-100"
              >
                <img
                  src={src}
                  alt={`Website showcase ${index + 1}`}
                  className="w-full h-full object-cover"
                />
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
