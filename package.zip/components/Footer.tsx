"use client";

import Link from "next/link";
import { Twitter, Instagram, Linkedin, Youtube } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-neutral-50 border-t border-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8">
          {/* Product Column */}
          <div>
            <h3 className="text-sm font-semibold text-neutral-900 mb-4">Product</h3>
            <ul className="space-y-3">
              <li><Link href="/ai/" className="text-sm text-neutral-600 hover:text-neutral-900">AI</Link></li>
              <li><Link href="/design/" className="text-sm text-neutral-600 hover:text-neutral-900">Design</Link></li>
              <li><Link href="/publish/" className="text-sm text-neutral-600 hover:text-neutral-900">Publish</Link></li>
              <li><Link href="/collaborate/" className="text-sm text-neutral-600 hover:text-neutral-900">Collaborate</Link></li>
              <li><Link href="/convert/" className="text-sm text-neutral-600 hover:text-neutral-900">Convert</Link></li>
              <li><Link href="/cms/" className="text-sm text-neutral-600 hover:text-neutral-900">CMS</Link></li>
              <li><Link href="/seo/" className="text-sm text-neutral-600 hover:text-neutral-900">SEO</Link></li>
              <li><Link href="/hosting/" className="text-sm text-neutral-600 hover:text-neutral-900">Hosting</Link></li>
              <li><Link href="/performance/" className="text-sm text-neutral-600 hover:text-neutral-900">Performance</Link></li>
              <li>
                <Link href="/updates/" className="text-sm text-neutral-600 hover:text-neutral-900 flex items-center">
                  Updates
                  <span className="ml-2 px-2 py-0.5 text-xs bg-green-100 text-green-700 rounded-full">NEW</span>
                </Link>
              </li>
            </ul>
          </div>

          {/* Business Column */}
          <div>
            <h3 className="text-sm font-semibold text-neutral-900 mb-4">Business</h3>
            <ul className="space-y-3">
              <li><Link href="/pricing/" className="text-sm text-neutral-600 hover:text-neutral-900">Pricing</Link></li>
              <li><Link href="/switch/" className="text-sm text-neutral-600 hover:text-neutral-900">Switch</Link></li>
              <li><Link href="/startups/" className="text-sm text-neutral-600 hover:text-neutral-900">Startups</Link></li>
              <li><Link href="/agencies/" className="text-sm text-neutral-600 hover:text-neutral-900">Agencies</Link></li>
              <li><Link href="/enterprise/" className="text-sm text-neutral-600 hover:text-neutral-900">Enterprise</Link></li>
            </ul>
          </div>

          {/* Solutions Column */}
          <div>
            <h3 className="text-sm font-semibold text-neutral-900 mb-4">Solutions</h3>
            <ul className="space-y-3">
              <li><Link href="/solutions/figma-to-html/" className="text-sm text-neutral-600 hover:text-neutral-900">Figma to HTML</Link></li>
              <li><Link href="/solutions/website-builder/" className="text-sm text-neutral-600 hover:text-neutral-900">Website builder</Link></li>
              <li><Link href="/solutions/portfolio-website/" className="text-sm text-neutral-600 hover:text-neutral-900">Portfolio maker</Link></li>
              <li><Link href="/solutions/landing-pages/" className="text-sm text-neutral-600 hover:text-neutral-900">Landing pages</Link></li>
              <li><Link href="/solutions/ui-ux-design/" className="text-sm text-neutral-600 hover:text-neutral-900">UI/UX design</Link></li>
              <li><Link href="/solutions/no-code-website-builder/" className="text-sm text-neutral-600 hover:text-neutral-900">No-code</Link></li>
            </ul>
          </div>

          {/* Compare Column */}
          <div>
            <h3 className="text-sm font-semibold text-neutral-900 mb-4">Compare</h3>
            <ul className="space-y-3">
              <li><Link href="/compare/framer-vs-claude-code/" className="text-sm text-neutral-600 hover:text-neutral-900">Claude Code</Link></li>
              <li><Link href="/compare/framer-vs-squarespace/" className="text-sm text-neutral-600 hover:text-neutral-900">Squarespace</Link></li>
              <li><Link href="/compare/framer-vs-wordpress/" className="text-sm text-neutral-600 hover:text-neutral-900">WordPress</Link></li>
              <li><Link href="/compare/framer-vs-webflow/" className="text-sm text-neutral-600 hover:text-neutral-900">Webflow</Link></li>
              <li><Link href="/compare/framer-vs-lovable/" className="text-sm text-neutral-600 hover:text-neutral-900">Lovable</Link></li>
              <li><Link href="/compare/framer-vs-figma/" className="text-sm text-neutral-600 hover:text-neutral-900">Figma</Link></li>
              <li><Link href="/compare/framer-vs-wix/" className="text-sm text-neutral-600 hover:text-neutral-900">Wix</Link></li>
            </ul>
          </div>

          {/* Resources Column */}
          <div>
            <h3 className="text-sm font-semibold text-neutral-900 mb-4">Resources</h3>
            <ul className="space-y-3">
              <li><Link href="/marketplace/" className="text-sm text-neutral-600 hover:text-neutral-900">Marketplace</Link></li>
              <li><Link href="/marketplace/templates/" className="text-sm text-neutral-600 hover:text-neutral-900">Templates</Link></li>
              <li><Link href="/marketplace/components/" className="text-sm text-neutral-600 hover:text-neutral-900">Components</Link></li>
              <li><Link href="/marketplace/plugins/" className="text-sm text-neutral-600 hover:text-neutral-900">Plugins</Link></li>
              <li><Link href="/marketplace/vectors/" className="text-sm text-neutral-600 hover:text-neutral-900">Vectors</Link></li>
              <li><Link href="/domains/" className="text-sm text-neutral-600 hover:text-neutral-900">Free domains</Link></li>
              <li>
                <Link href="/state-of-sites-2026/" className="text-sm text-neutral-600 hover:text-neutral-900 flex items-center">
                  State of Sites
                  <span className="ml-2 px-2 py-0.5 text-xs bg-green-100 text-green-700 rounded-full">NEW</span>
                </Link>
              </li>
              <li><Link href="/stories/" className="text-sm text-neutral-600 hover:text-neutral-900">Case studies</Link></li>
              <li><Link href="/developers/" className="text-sm text-neutral-600 hover:text-neutral-900">Developers</Link></li>
              <li><Link href="/newsletter/" className="text-sm text-neutral-600 hover:text-neutral-900">Newsletter</Link></li>
              <li><Link href="/help/" className="text-sm text-neutral-600 hover:text-neutral-900">Support</Link></li>
              <li><Link href="/contact/" className="text-sm text-neutral-600 hover:text-neutral-900">Contact</Link></li>
              <li><Link href="/guides/" className="text-sm text-neutral-600 hover:text-neutral-900">Guides</Link></li>
              <li><Link href="/brand/" className="text-sm text-neutral-600 hover:text-neutral-900">Brand</Link></li>
              <li><Link href="/blog/" className="text-sm text-neutral-600 hover:text-neutral-900">Blog</Link></li>
            </ul>
          </div>

          {/* Company Column */}
          <div>
            <h3 className="text-sm font-semibold text-neutral-900 mb-4">Company</h3>
            <ul className="space-y-3">
              <li><Link href="/meetups/" className="text-sm text-neutral-600 hover:text-neutral-900">Meetups</Link></li>
              <li><Link href="/careers/" className="text-sm text-neutral-600 hover:text-neutral-900">Careers</Link></li>
              <li><Link href="/legal/security/" className="text-sm text-neutral-600 hover:text-neutral-900">Security</Link></li>
              <li><Link href="/legal/" className="text-sm text-neutral-600 hover:text-neutral-900">Legal</Link></li>
              <li><Link href="/store/" className="text-sm text-neutral-600 hover:text-neutral-900">Store</Link></li>
              <li><Link href="/trust-center/" className="text-sm text-neutral-600 hover:text-neutral-900">Trust center</Link></li>
            </ul>

            <h3 className="text-sm font-semibold text-neutral-900 mt-8 mb-4">Programs</h3>
            <ul className="space-y-3">
              <li><Link href="/experts/" className="text-sm text-neutral-600 hover:text-neutral-900">Experts</Link></li>
              <li><Link href="/creators/" className="text-sm text-neutral-600 hover:text-neutral-900">Creators</Link></li>
              <li><Link href="/education/students/" className="text-sm text-neutral-600 hover:text-neutral-900">Students</Link></li>
              <li><Link href="/education/ambassadors/" className="text-sm text-neutral-600 hover:text-neutral-900">Ambassadors</Link></li>
            </ul>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="mt-16 pt-8 border-t border-neutral-200 flex flex-col md:flex-row items-center justify-between">
          <div className="flex items-center space-x-4 mb-4 md:mb-0">
            <Link href="/" className="flex items-center">
              <svg
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                className="text-black"
              >
                <path
                  d="M4 0H20V8H12V16H20V24H4V16H12V8H4V0Z"
                  fill="currentColor"
                />
              </svg>
            </Link>
            <span className="text-sm text-neutral-500">© 2026 Framer B.V.</span>
          </div>

          <div className="flex items-center space-x-4">
            <Link href="https://x.com/framer" target="_blank" className="text-neutral-500 hover:text-neutral-900">
              <Twitter className="h-5 w-5" />
            </Link>
            <Link href="https://www.instagram.com/framer/" target="_blank" className="text-neutral-500 hover:text-neutral-900">
              <Instagram className="h-5 w-5" />
            </Link>
            <Link href="https://www.linkedin.com/company/framer/" target="_blank" className="text-neutral-500 hover:text-neutral-900">
              <Linkedin className="h-5 w-5" />
            </Link>
            <Link href="https://www.youtube.com/@Framer" target="_blank" className="text-neutral-500 hover:text-neutral-900">
              <Youtube className="h-5 w-5" />
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
