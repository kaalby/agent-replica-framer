"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

const experts = [
  {
    name: "Trueform",
    location: "Switzerland",
    avatar: "https://framerusercontent.com/images/ef3wgXef7UtZHsMSvRwgFetdc.jpeg",
  },
  {
    name: "Alex Aperios",
    location: "United Kingdom",
    avatar: "https://framerusercontent.com/images/LGLA6ocNPTiDQkXmTgCNzigXM.jpeg",
  },
  {
    name: "Analogue Agency",
    location: "Netherlands",
    avatar: "https://framerusercontent.com/images/Juzj27np5nQ72k0J7YpYDkRadP8.jpeg",
  },
  {
    name: "Fabian Albert",
    location: "United States",
    avatar: "https://framerusercontent.com/images/lRJZqAacf8QpT647xsXwoU5Kn4.jpeg",
  },
  {
    name: "Allsite Studio",
    location: "Germany",
    avatar: "https://framerusercontent.com/images/ef3wgXef7UtZHsMSvRwgFetdc.jpeg",
  },
  {
    name: "Aerolab",
    location: "United States",
    avatar: "https://framerusercontent.com/images/sK7rKqHZBkgF2OJLJvHsHQSE1U.jpeg",
  },
  {
    name: "Adriano Reis",
    location: "United States",
    avatar: "https://framerusercontent.com/images/lRJZqAacf8QpT647xsXwoU5Kn4.jpeg",
  },
  {
    name: "Deserve Studio",
    location: "United States",
    avatar: "https://framerusercontent.com/images/Juzj27np5nQ72k0J7YpYDkRadP8.jpeg",
  },
];

export default function Experts() {
  return (
    <section className="py-20 lg:py-32 bg-neutral-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-neutral-900 mb-4">
            Get pro help from handpicked experts
          </h2>

          <div className="flex items-center justify-center gap-4 mt-8">
            <Link
              href="/match/"
              className="inline-flex items-center px-6 py-3 bg-black text-white rounded-lg font-medium hover:bg-neutral-800 transition-colors"
            >
              Get matched
            </Link>
            <Link
              href="/experts/"
              className="inline-flex items-center px-6 py-3 bg-white border border-neutral-200 text-neutral-900 rounded-lg font-medium hover:bg-neutral-50 transition-colors"
            >
              Find an Expert
            </Link>
          </div>
        </motion.div>

        {/* Experts Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-12">
          {experts.map((expert, index) => (
            <motion.div
              key={expert.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: index * 0.05 }}
            >
              <Link
                href={`/@${expert.name.toLowerCase().replace(/\s+/g, "-")}/`}
                className="group block bg-white rounded-xl p-4 border border-neutral-200/50 hover:border-neutral-300 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <img
                    src={expert.avatar}
                    alt={expert.name}
                    className="h-10 w-10 rounded-full object-cover"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-neutral-900 truncate">
                      Avatar {expert.name}
                    </p>
                    <p className="text-xs text-neutral-500">{expert.location}</p>
                  </div>
                </div>
                <button className="mt-4 w-full py-2 text-sm font-medium text-neutral-700 bg-neutral-100 rounded-lg group-hover:bg-neutral-200 transition-colors">
                  View Expert
                </button>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
