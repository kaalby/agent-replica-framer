"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { ArrowRight, BarChart3, FlaskConical, Zap } from "lucide-react";

const scaleFeatures = [
  {
    icon: BarChart3,
    title: "Analytics & insights",
    description: "Track traffic, measure performance, and monitor conversions.",
    link: "/analytics/",
  },
  {
    icon: FlaskConical,
    title: "A/B Testing & optimization",
    description: "A/B testing, funnels, and built-in growth insights.",
    link: "/convert/",
  },
  {
    icon: Zap,
    title: "SEO & performance",
    description:
      "Optimize every page with built-in SEO settings, metadata, and blazing-fast hosting.",
    link: "/seo/",
  },
];

export default function ScaleSection() {
  return (
    <section className="py-20 lg:py-32 bg-neutral-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-neutral-900 mb-4">
            Scale without switching tools
          </h2>
        </motion.div>

        {/* Scale Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {scaleFeatures.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group relative bg-white rounded-2xl p-8 border border-neutral-200/50 hover:border-neutral-300 transition-colors"
            >
              <div className="flex items-center gap-3 mb-4">
                <feature.icon className="h-5 w-5 text-neutral-600" />
                <span className="text-xs font-semibold text-neutral-500 uppercase tracking-wider">
                  {feature.title.split(" ")[0]}
                </span>
              </div>

              <h3 className="text-xl font-semibold text-neutral-900 mb-3">
                {feature.title}
              </h3>

              <p className="text-neutral-600 mb-6">{feature.description}</p>

              <Link
                href={feature.link}
                className="inline-flex items-center text-sm font-semibold text-neutral-900 hover:text-primary transition-colors"
              >
                Learn more
                <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
              </Link>
            </motion.div>
          ))}
        </div>

        {/* Feature Image */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mt-12 grid grid-cols-1 lg:grid-cols-2 gap-8"
        >
          <div className="relative rounded-2xl overflow-hidden bg-neutral-100 aspect-[4/3]">
            <img
              src="https://framerusercontent.com/images/Vop2a6Qgb62EAIB7lEzyqGTu2h0.png"
              alt="Framer UI showcasing design interface"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="relative rounded-2xl overflow-hidden bg-neutral-100 aspect-[4/3]">
            <img
              src="https://framerusercontent.com/images/FAI4P9UsKm9pcZ4Y24wWOedWPw.png"
              alt="Framer performance dashboard"
              className="w-full h-full object-cover"
            />
          </div>
        </motion.div>

        {/* Lighthouse Score */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="mt-12 flex justify-center"
        >
          <div className="inline-flex items-center gap-4 bg-white rounded-xl px-6 py-4 border border-neutral-200/50">
            <img
              src="https://framerusercontent.com/images/SVq3wMjRzI8z4l7yg3MqXxi0cw.png"
              alt="Lighthouse performance score 100"
              className="h-12 w-auto"
            />
            <div>
              <p className="text-sm font-medium text-neutral-900">
                Perfect Lighthouse scores
              </p>
              <p className="text-xs text-neutral-500">
                Out of the box performance optimization
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
