"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

type TabType = "templates" | "plugins" | "components";

const marketplaceItems: Record<TabType, Array<{
  title: string;
  description: string;
  image: string;
  link: string;
  type: string;
}>> = {
  templates: [
    {
      title: "Milo",
      description: "Furniture shop website",
      image: "https://framerusercontent.com/images/d4YjsL7yalSYZREJ1IdNPmw.jpg",
      link: "/marketplace/templates/milo/",
      type: "Template",
    },
    {
      title: "Archer",
      description: "Creative portfolio",
      image: "https://framerusercontent.com/images/W1Q88PlQfYXaGug9EBkmai9By4.jpg",
      link: "/marketplace/templates/archer/",
      type: "Template",
    },
    {
      title: "Apex Films",
      description: "Multimedia portfolio",
      image: "https://framerusercontent.com/images/uS0nUv30GToaflDaraI9qVUIwU.png",
      link: "/marketplace/templates/apex-films/",
      type: "Template",
    },
    {
      title: "Baseform",
      description: "Modern design portfolio",
      image: "https://framerusercontent.com/images/gmhdX4XPuJvQqId9jDmFHb7cFE.jpg",
      link: "/marketplace/templates/baseform/",
      type: "Template",
    },
  ],
  plugins: [
    {
      title: "Notion",
      description: "Sync with Notion",
      image: "https://framerusercontent.com/images/c8yQcxKjBlCZWoqWoRoBRvjcKo.jpg",
      link: "/marketplace/plugins/notion/",
      type: "Plugin",
    },
    {
      title: "Workshop",
      description: "Turn ideas into components",
      image: "https://framerusercontent.com/images/Hp4KG1pwKb6cl66bNB9b2pYWQ3Y.jpg",
      link: "/marketplace/plugins/workshop/",
      type: "Plugin",
    },
    {
      title: "JSON Sync",
      description: "Import & export CMS with JSON",
      image: "https://framerusercontent.com/images/cx71XZYYWfIozOc1rn55Bw.jpg",
      link: "/marketplace/plugins/json-sync/",
      type: "Plugin",
    },
    {
      title: "Asset Manager",
      description: "Manage your site&apos;s assets",
      image: "https://framerusercontent.com/images/4pTVxnxo0Bvii8xP7hCmmozqx7s.jpg",
      link: "/marketplace/plugins/asset-manager/",
      type: "Plugin",
    },
  ],
  components: [
    {
      title: "Image Slider",
      description: "Before and after images",
      image: "https://framerusercontent.com/images/8VfS5zuMmDchIpaCf767I8rX7Y.jpg",
      link: "/marketplace/components/image-slider/",
      type: "Component",
    },
    {
      title: "Hover Zoom",
      description: "Zoom and pan on hover",
      image: "https://framerusercontent.com/images/KCk7nP2M4mP1QclNxHPIrT1FvcA.jpg",
      link: "/marketplace/components/hover-image-zoom/",
      type: "Component",
    },
    {
      title: "Digital Rotary Radio",
      description: "Fully functional radio",
      image: "https://framerusercontent.com/images/6SXUv7jMAEkw8PabtmC6TXNIiM.jpg",
      link: "/marketplace/components/digital-rotary-radio/",
      type: "Component",
    },
    {
      title: "Flip Card",
      description: "Drag to flip cards",
      image: "https://framerusercontent.com/images/PruQlxKuftAZHgOh7hJT3jaUbs.jpg",
      link: "/marketplace/components/flipcard-component/",
      type: "Component",
    },
    {
      title: "Animated Gradients",
      description: "Image reveal effect",
      image: "https://framerusercontent.com/images/d4YjsL7yalSYZREJ1IdNPmw.jpg",
      link: "/marketplace/components/animated-gradient/",
      type: "Component",
    },
    {
      title: "Video Player",
      description: "Beautiful video player",
      image: "https://framerusercontent.com/images/W1Q88PlQfYXaGug9EBkmai9By4.jpg",
      link: "/marketplace/components/videoplayer/",
      type: "Component",
    },
  ],
};

export default function Marketplace() {
  const [activeTab, setActiveTab] = useState<TabType>("templates");

  return (
    <section className="py-20 lg:py-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-neutral-900 mb-4">
            Launch faster with community resources
          </h2>
        </motion.div>

        {/* Tabs */}
        <div className="flex items-center justify-center gap-2 mb-12">
          {(["templates", "plugins", "components"] as TabType[]).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-6 py-3 rounded-full text-sm font-medium capitalize transition-colors ${
                activeTab === tab
                  ? "bg-black text-white"
                  : "bg-neutral-100 text-neutral-700 hover:bg-neutral-200"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Items Grid */}
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {marketplaceItems[activeTab].map((item, index) => (
            <Link
              key={item.title}
              href={item.link}
              className="group relative bg-neutral-50 rounded-2xl overflow-hidden hover:shadow-lg transition-shadow"
            >
              <div className="relative aspect-[4/3] overflow-hidden">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-4">
                  <p className="text-xs font-medium text-white/80 mb-1">
                    Framer marketplace item
                  </p>
                  <h3 className="text-lg font-semibold text-white">{item.title}</h3>
                  <p className="text-sm text-white/80">{item.description}</p>
                </div>
              </div>
              <div className="p-4 flex items-center justify-between">
                <span className="text-xs font-medium text-neutral-500">
                  View {item.type}
                </span>
                <button className="p-2 rounded-lg bg-neutral-100 group-hover:bg-neutral-200 transition-colors">
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </Link>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
