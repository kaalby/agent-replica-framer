"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight, Quote } from "lucide-react";

const testimonials = [
  {
    quote:
      "With Framer, our designers can ship updates daily. No dev handoff. No staging hassle.",
    author: "Jelle Prins",
    role: "Co-Founder at Cradle",
    company: "Cradle",
    logo: "https://framerusercontent.com/images/RkwWTf2otULCGv3QEORgS5bH7Eg.png",
    avatar: "https://framerusercontent.com/images/ef3wgXef7UtZHsMSvRwgFetdc.jpeg",
    website: "https://www.framer.com/stories/cradle/",
    background: "https://framerusercontent.com/images/QgULASvPNPL1E26jYHejis2LxM.jpg",
  },
  {
    quote:
      "Framer allowed us to ship high-performing, beautifully designed pages at record speed, all while keeping design control in-house.",
    author: "Radoslav Bali",
    role: "Design Lead at Miro",
    company: "Miro",
    logo: "https://framerusercontent.com/images/f0zD56BWH0z8GfKM9dd8nMsCkc.png",
    avatar: "https://framerusercontent.com/images/LGLA6ocNPTiDQkXmTgCNzigXM.jpeg",
    website: "https://www.framer.com/stories/miro/",
    background: "https://framerusercontent.com/images/qxEBdj3ZfKwjiQwXRhWNrGpy3g.jpg",
  },
  {
    quote:
      "Framer has completely transformed how we approach web design. The speed from concept to live site is unmatched.",
    author: "Sarah Chen",
    role: "Head of Design at Perplexity",
    company: "Perplexity",
    logo: "https://framerusercontent.com/images/4gKZnsOSKARj5SbgbbbF1CNqro.png",
    avatar: "https://framerusercontent.com/images/Juzj27np5nQ72k0J7YpYDkRadP8.jpeg",
    website: "https://www.framer.com/stories/",
    background: "https://framerusercontent.com/images/fHZdIY2t1thgqdgOd1Z1bI4zYo.jpg",
  },
  {
    quote:
      "The ability to iterate quickly and see changes in real-time has made our design process 10x more efficient.",
    author: "Michael Torres",
    role: "Creative Director",
    company: "Biograph",
    logo: "https://framerusercontent.com/images/VVlSsBCZwRNiKHsE4BiCZqBThM.png",
    avatar: "https://framerusercontent.com/images/lRJZqAacf8QpT647xsXwoU5Kn4.jpeg",
    website: "https://www.framer.com/stories/",
    background: "https://framerusercontent.com/images/GtBh9i5DeLNj6hcHPwwALi4SmQ.jpg",
  },
  {
    quote:
      "We rebuilt our entire marketing site in Framer and saw an immediate improvement in conversion rates.",
    author: "Emma Wilson",
    role: "VP of Marketing",
    company: "OpenAI",
    logo: "https://framerusercontent.com/images/O7xswHZEokohIpEuVGSmjWTUMc.png",
    avatar: "https://framerusercontent.com/images/sK7rKqHZBkgF2OJLJvHsHQSE1U.jpeg",
    website: "https://www.framer.com/stories/",
    background: "https://framerusercontent.com/images/wD6CCUIINtCNzgZW9HQtNnW0YrU.jpg",
  },
];

export default function Testimonials() {
  const [current, setCurrent] = useState(0);

  const next = () => {
    setCurrent((prev) => (prev + 1) % testimonials.length);
  };

  const prev = () => {
    setCurrent((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const testimonial = testimonials[current];

  return (
    <section className="py-20 lg:py-32 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-neutral-900 mb-4">
            Powering ambitious teams worldwide
          </h2>
        </motion.div>

        {/* Testimonial Card */}
        <div className="relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={current}
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -100 }}
              transition={{ duration: 0.5 }}
              className="relative"
            >
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-16 items-center">
                {/* Quote Side */}
                <div className="order-2 lg:order-1">
                  <div className="flex items-center gap-3 mb-6">
                    <img
                      src={testimonial.logo}
                      alt={testimonial.company}
                      className="h-8 w-8 object-contain"
                    />
                    <span className="text-sm font-medium text-neutral-600">
                      {testimonial.company} logo
                    </span>
                  </div>

                  <Quote className="h-10 w-10 text-neutral-200 mb-6" />

                  <blockquote className="text-2xl md:text-3xl font-medium text-neutral-900 mb-8 leading-relaxed">
                    &ldquo;{testimonial.quote}&rdquo;
                  </blockquote>

                  <div className="flex items-center gap-4">
                    <img
                      src={testimonial.avatar}
                      alt={testimonial.author}
                      className="h-12 w-12 rounded-full object-cover"
                    />
                    <div>
                      <p className="font-medium text-neutral-900">
                        Avatar {testimonial.author}
                      </p>
                      <p className="text-sm text-neutral-600">{testimonial.role}</p>
                    </div>
                  </div>

                  <a
                    href={testimonial.website}
                    className="inline-flex items-center mt-6 text-sm text-neutral-600 hover:text-neutral-900 underline underline-offset-4"
                  >
                    Read more {testimonial.company} website
                  </a>
                </div>

                {/* Image Side */}
                <div className="order-1 lg:order-2">
                  <div className="relative aspect-square rounded-2xl overflow-hidden bg-neutral-100">
                    <img
                      src={testimonial.background}
                      alt={`${testimonial.company} website background`}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
                  </div>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Navigation */}
          <div className="flex items-center justify-center gap-4 mt-12">
            <button
              onClick={prev}
              className="p-3 rounded-full border border-neutral-200 hover:bg-neutral-50 transition-colors"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>

            <div className="flex items-center gap-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrent(index)}
                  className={`h-2 rounded-full transition-all ${
                    index === current
                      ? "w-8 bg-neutral-900"
                      : "w-2 bg-neutral-300 hover:bg-neutral-400"
                  }`}
                />
              ))}
            </div>

            <button
              onClick={next}
              className="p-3 rounded-full border border-neutral-200 hover:bg-neutral-50 transition-colors"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
