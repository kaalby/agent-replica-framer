"use client";

import { useState } from "react";
import Link from "next/link";
import { Menu, X, ChevronDown } from "lucide-react";

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [productOpen, setProductOpen] = useState(false);
  const [resourcesOpen, setResourcesOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-neutral-200/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center">
            <svg
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="text-black"
            >
              <path
                d="M4 0H20V8H12V16H20V24H4V16H12V8H4V0Z"
                fill="currentColor"
              />
            </svg>
            <span className="ml-2 text-xl font-semibold">Framer</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-1">
            {/* Product Dropdown */}
            <div className="relative">
              <button
                className="flex items-center px-3 py-2 text-sm font-medium text-neutral-700 hover:text-neutral-900 rounded-lg hover:bg-neutral-100 transition-colors"
                onMouseEnter={() => setProductOpen(true)}
                onMouseLeave={() => setProductOpen(false)}
              >
                Product
                <ChevronDown className="ml-1 h-4 w-4" />
              </button>
              {productOpen && (
                <div
                  className="absolute top-full left-0 w-64 bg-white rounded-xl shadow-xl border border-neutral-200/50 py-2 mt-1"
                  onMouseEnter={() => setProductOpen(true)}
                  onMouseLeave={() => setProductOpen(false)}
                >
                  <Link href="/ai/" className="block px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-50 hover:text-primary">
                    AI
                  </Link>
                  <Link href="/design/" className="block px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-50 hover:text-primary">
                    Design
                  </Link>
                  <Link href="/publish/" className="block px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-50 hover:text-primary">
                    Publish
                  </Link>
                  <Link href="/collaborate/" className="block px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-50 hover:text-primary">
                    Collaborate
                  </Link>
                  <Link href="/convert/" className="block px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-50 hover:text-primary">
                    Convert
                  </Link>
                  <Link href="/cms/" className="block px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-50 hover:text-primary">
                    CMS
                  </Link>
                  <Link href="/seo/" className="block px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-50 hover:text-primary">
                    SEO
                  </Link>
                  <Link href="/hosting/" className="block px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-50 hover:text-primary">
                    Hosting
                  </Link>
                  <Link href="/performance/" className="block px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-50 hover:text-primary">
                    Performance
                  </Link>
                </div>
              )}
            </div>

            <Link href="/stories/" className="px-3 py-2 text-sm font-medium text-neutral-700 hover:text-neutral-900 rounded-lg hover:bg-neutral-100 transition-colors">
              Customers
            </Link>

            <Link href="/pricing/" className="px-3 py-2 text-sm font-medium text-neutral-700 hover:text-neutral-900 rounded-lg hover:bg-neutral-100 transition-colors">
              Pricing
            </Link>

            <Link href="/marketplace/" className="px-3 py-2 text-sm font-medium text-neutral-700 hover:text-neutral-900 rounded-lg hover:bg-neutral-100 transition-colors">
              Marketplace
            </Link>

            {/* Resources Dropdown */}
            <div className="relative">
              <button
                className="flex items-center px-3 py-2 text-sm font-medium text-neutral-700 hover:text-neutral-900 rounded-lg hover:bg-neutral-100 transition-colors"
                onMouseEnter={() => setResourcesOpen(true)}
                onMouseLeave={() => setResourcesOpen(false)}
              >
                Resources
                <ChevronDown className="ml-1 h-4 w-4" />
              </button>
              {resourcesOpen && (
                <div
                  className="absolute top-full left-0 w-56 bg-white rounded-xl shadow-xl border border-neutral-200/50 py-2 mt-1"
                  onMouseEnter={() => setResourcesOpen(true)}
                  onMouseLeave={() => setResourcesOpen(false)}
                >
                  <Link href="/guides/" className="block px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-50 hover:text-primary">
                    Guides
                  </Link>
                  <Link href="/blog/" className="block px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-50 hover:text-primary">
                    Blog
                  </Link>
                  <Link href="/experts/" className="block px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-50 hover:text-primary">
                    Experts
                  </Link>
                </div>
              )}
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="hidden lg:flex items-center space-x-3">
            <Link
              href="/login/"
              className="px-4 py-2 text-sm font-medium text-neutral-700 hover:text-neutral-900 transition-colors"
            >
              Log in
            </Link>
            <Link
              href="/signup/"
              className="px-4 py-2 text-sm font-medium bg-black text-white rounded-lg hover:bg-neutral-800 transition-colors"
            >
              Start for free
            </Link>
          </div>

          {/* Mobile menu button */}
          <button
            className="lg:hidden p-2 rounded-lg hover:bg-neutral-100"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="lg:hidden py-4 border-t border-neutral-200">
            <div className="space-y-1">
              <p className="px-3 py-2 text-xs font-semibold text-neutral-500 uppercase tracking-wider">
                Product
              </p>
              <Link href="/ai/" className="block px-3 py-2 text-sm text-neutral-700 hover:bg-neutral-50 rounded-lg">
                AI
              </Link>
              <Link href="/design/" className="block px-3 py-2 text-sm text-neutral-700 hover:bg-neutral-50 rounded-lg">
                Design
              </Link>
              <Link href="/publish/" className="block px-3 py-2 text-sm text-neutral-700 hover:bg-neutral-50 rounded-lg">
                Publish
              </Link>
              <Link href="/cms/" className="block px-3 py-2 text-sm text-neutral-700 hover:bg-neutral-50 rounded-lg">
                CMS
              </Link>
              <Link href="/seo/" className="block px-3 py-2 text-sm text-neutral-700 hover:bg-neutral-50 rounded-lg">
                SEO
              </Link>
            </div>
            <div className="mt-4 pt-4 border-t border-neutral-200 space-y-2">
              <Link href="/pricing/" className="block px-3 py-2 text-sm text-neutral-700 hover:bg-neutral-50 rounded-lg">
                Pricing
              </Link>
              <Link href="/stories/" className="block px-3 py-2 text-sm text-neutral-700 hover:bg-neutral-50 rounded-lg">
                Customers
              </Link>
              <Link href="/marketplace/" className="block px-3 py-2 text-sm text-neutral-700 hover:bg-neutral-50 rounded-lg">
                Marketplace
              </Link>
              <Link
                href="/signup/"
                className="block px-3 py-2 text-sm font-medium bg-black text-white rounded-lg text-center"
              >
                Start for free
              </Link>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
