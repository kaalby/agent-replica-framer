"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { ArrowRight, Sparkles, Palette, Database, Users } from "lucide-react";

const features = [
  {
    icon: Sparkles,
    title: "AI",
    description:
      "Generate page layouts and advanced components in seconds with AI, so you can skip the blank canvas and start designing with confidence.",
    image: "https://framerusercontent.com/images/ZilMOyVNFhcvNyS9pG0hfM0Dv0.jpg",
    link: "/ai/",
  },
  {
    icon: Palette,
    title: "Design",
    description:
      "Craft responsive layouts and bring them to life with smooth effects, interactions, and animations. Build exactly what you imagine, visually.",
    image: "https://framerusercontent.com/images/AyPzyMylJEo92lHDAr0UVgNN0.jpg",
    link: "/design/",
  },
  {
    icon: Database,
    title: "CMS",
    description:
      "Manage and update your content effortlessly with a built-in CMS. Keep your site fresh without touching code.",
    image: "https://framerusercontent.com/images/w6D0Go6oSPqwIy3aBNxBEnvA8.png",
    link: "/cms/",
  },
  {
    icon: Users,
    title: "Collaborate",
    description:
      "Whether you're collaborating on the canvas or editing copy directly on the page, updates are seamless and handoff-free.",
    image: "https://framerusercontent.com/images/WB79UA8D6HufwUmuGE9WE1kIvD0.jpg",
    link: "/collaborate/",
  },
];

export default function Features() {
  return (
    <section className="py-20 lg:py-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-neutral-900 mb-4">
            Create, collaborate, and go live
          </h2>
        </motion.div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group relative bg-neutral-50 rounded-2xl overflow-hidden"
            >
              <div className="p-8 lg:p-10">
                <div className="flex items-start gap-4 mb-6">
                  <div className="p-3 bg-white rounded-xl shadow-sm">
                    <feature.icon className="h-6 w-6 text-neutral-900" />
                  </div>
                  <div>
                    <span className="text-xs font-semibold text-neutral-500 uppercase tracking-wider">
                      {feature.title}
                    </span>
                  </div>
                </div>

                <p className="text-lg text-neutral-600 mb-6 leading-relaxed">
                  {feature.description}
                </p>

                <Link
                  href={feature.link}
                  className="inline-flex items-center text-sm font-medium text-neutral-900 hover:text-primary transition-colors"
                >
                  Learn more
                  <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </Link>
              </div>

              <div className="relative aspect-[16/10] overflow-hidden">
                <img
                  src={feature.image}
                  alt={feature.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
