"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { Sparkles } from "lucide-react";

export default function CTA() {
  return (
    <section className="py-20 lg:py-32">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <div className="inline-flex items-center px-4 py-2 bg-green-100 text-green-800 rounded-full text-sm font-medium mb-6">
            <span className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse" />
            All systems operational
          </div>

          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-neutral-900 mb-8">
            Design bold. Launch fast.
          </h2>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              href="/signup/"
              className="inline-flex items-center px-6 py-3 bg-black text-white rounded-lg font-medium hover:bg-neutral-800 transition-colors"
            >
              Start for free
            </Link>
            <Link
              href="/ai/"
              className="inline-flex items-center px-6 py-3 bg-white border border-neutral-200 text-neutral-900 rounded-lg font-medium hover:bg-neutral-50 transition-colors"
            >
              <Sparkles className="mr-2 h-4 w-4" />
              Start with AI
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
